const assetPathPrefix = "/assets";

const imgVector = `${assetPathPrefix}/adfc0.svg`;
const imgVector1 = `${assetPathPrefix}/91f3e.svg`;
const imgVector2 = `${assetPathPrefix}/21ba9.svg`;
const imgVector3 = `${assetPathPrefix}/6d60e.svg`;
const imgVector4 = `${assetPathPrefix}/5e8b9.svg`;
const imgVector5 = `${assetPathPrefix}/7d629.svg`;
const imgVector6 = `${assetPathPrefix}/586bd.svg`;
const imgVector7 = `${assetPathPrefix}/9ac0e.svg`;
const imgVector8 = `${assetPathPrefix}/5103e.svg`;
const imgVector9 = `${assetPathPrefix}/d1303.svg`;
const imgVector10 = `${assetPathPrefix}/d6115.svg`;
const imgVector11 = `${assetPathPrefix}/35ac7.svg`;
const imgVector12 = `${assetPathPrefix}/4d51e.svg`;
const imgVector13 = `${assetPathPrefix}/90819.svg`;
const imgVector14 = `${assetPathPrefix}/05268.svg`;
const imgVector15 = `${assetPathPrefix}/3b403.svg`;
const imgVector16 = `${assetPathPrefix}/24379.svg`;
const imgFjord = `${assetPathPrefix}/e2418.png`;
const imgHero = `${assetPathPrefix}/35754.png`;

type StarProps = { className?: string; variant?: "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" };

function StarIcon({ className, variant = "1" }: StarProps) {
  const is10 = variant === "10";
  const is9 = variant === "9";
  const is8 = variant === "8";
  const is7 = variant === "7";
  const is6 = variant === "6";
  const is5 = variant === "5";
  const is4 = variant === "4";
  const is3 = variant === "3";
  const is2 = variant === "2";
  const multiVariant = ["2","3","4","5","6","7"].includes(variant);

  return (
    <div className={className || `overflow-clip relative ${is10 ? "size-[13px]" : multiVariant ? "opacity-70 size-[22px]" : "size-[14px]"}`}>
      <div className={`absolute ${is10 ? "bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4" : is9 ? "bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" : is8 ? "inset-[16.67%_12.5%_8.33%_12.5%]" : is7 ? "inset-[8.33%_16.66%]" : is6 ? "bottom-1/2 left-[8.33%] right-[8.33%] top-[8.33%]" : is5 ? "inset-[8.33%]" : is4 ? "inset-[8.33%_8.33%_12.5%_12.5%]" : is3 ? "inset-[16.67%_16.67%_8.33%_16.67%]" : is2 ? "inset-[12.5%]" : "inset-[8.33%_8.33%_12.42%_8.33%]"}`}>
        {["2","3","4","5","6","7","8","9","10"].includes(variant) && (
          <div className={`absolute ${is10 ? "inset-[-6.82%_-4.69%_-9.64%_-4.69%]" : is9 ? "inset-[-8.84%_-4.42%_-17.68%_-4.42%]" : is8 ? "inset-[-4.17%]" : is7 ? "inset-[-3.5%_-4.37%_-4.02%_-4.37%]" : is6 ? "inset-[-7.83%]" : is5 ? "inset-[-3.5%]" : is4 ? "inset-[-7.75%_-7.75%_-10.88%_-10.88%]" : is3 ? "inset-[-3.89%_-4.37%]" : "inset-[-3.89%]"}`}>
            <img alt="" className="block max-w-none size-full" src={is10 ? imgVector16 : is9 ? imgVector15 : is8 ? imgVector12 : is7 ? imgVector11 : is6 ? imgVector9 : is5 ? imgVector6 : is4 ? imgVector5 : is3 ? imgVector3 : imgVector1} />
          </div>
        )}
        {variant === "1" && <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgVector} />}
      </div>
      {["2","3","5","6","8"].includes(variant) && (
        <div className={`absolute ${is8 ? "bottom-3/4 left-[66.67%] right-[33.33%] top-[8.33%]" : is6 ? "inset-[70.83%_8.33%_8.33%_8.33%]" : is5 ? "inset-[8.33%_33.33%]" : is3 ? "bottom-1/4 left-[16.67%] right-[16.67%] top-3/4" : "bottom-[37.5%] left-1/2 right-[37.5%] top-[33.33%]"}`}>
          <div className={`absolute ${is8 ? "inset-[0_-0.44px]" : is6 ? "inset-[-14%_-3.5%_-15.65%_-3.5%]" : is5 ? "inset-[-5.07%_-8.75%]" : is3 ? "inset-[-0.64px_-4.37%]" : "inset-[-10%_-23.33%]"}`}>
            <img alt="" className="block max-w-none size-full" src={is8 ? imgVector13 : is6 ? imgVector10 : is5 ? imgVector7 : is3 ? imgVector4 : imgVector2} />
          </div>
        </div>
      )}
      {["5","6","8"].includes(variant) && (
        <div className={`absolute ${is8 ? "bottom-3/4 left-[33.33%] right-[66.67%] top-[8.33%]" : is6 ? "bottom-[29.17%] left-[8.33%] right-[8.33%] top-1/2" : "bottom-1/2 left-[8.33%] right-[8.33%] top-1/2"}`}>
          <div className={`absolute ${is8 ? "inset-[0_-0.44px]" : is6 ? "inset-[-14%_-3.5%_-15.65%_-3.5%]" : "inset-[-0.64px_-3.5%]"}`}>
            <img alt="" className="block max-w-none size-full" src={is8 ? imgVector13 : is6 ? imgVector10 : imgVector8} />
          </div>
        </div>
      )}
      {is8 && (
        <div className="absolute inset-[41.67%_12.5%_58.33%_12.5%]">
          <div className="absolute inset-[-0.44px_0]">
            <img alt="" className="block max-w-none size-full" src={imgVector14} />
          </div>
        </div>
      )}
    </div>
  );
}

const amenities = [
  { variant: "2" as const, category: "Signature", name: "Heated Glass Domes" },
  { variant: "3" as const, category: "Wellness", name: "Arctic Thermal Spa" },
  { variant: "4" as const, category: "Dining", name: "Michelin Nordic Kitchen" },
  { variant: "5" as const, category: "Excursion", name: "Fjord Expeditions" },
  { variant: "6" as const, category: "Service", name: "Aurora Concierge" },
  { variant: "7" as const, category: "Private", name: "Private Heli-Pad" },
];

export default function App() {
  return (
    <div className="bg-white min-h-dvh flex flex-col" style={{ fontFamily: "'Manrope', sans-serif" }}>
      {/* NAV */}
      <header className="sticky top-0 z-50 backdrop-blur-[12px] bg-[rgba(246,250,254,0.85)] border-b border-[#e2e2e2]">
        <div className="max-w-[1280px] mx-auto px-8 md:px-12 py-5 flex items-center justify-between">
          <div className="text-[#1b2a4a] text-[18px] tracking-[4px] uppercase font-light" style={{ fontFamily: "'Noto Serif', serif" }}>
            Arctic Travels
          </div>
          <nav className="hidden md:flex items-center gap-9">
            {["Locations","Resorts","Experiences","Passes"].map(link => (
              <a key={link} href="#" className="text-[rgba(27,42,74,0.7)] text-[15px] tracking-[0.4px] hover:text-[#1b2a4a] transition-colors" style={{ fontFamily: "'Noto Serif', serif" }}>{link}</a>
            ))}
          </nav>
          <div className="flex items-center gap-6">
            <a href="#" className="text-[11px] tracking-[1.2px] uppercase text-black font-normal hidden sm:block">Sign In</a>
            <button className="bg-[#1b2a4a] text-white text-[13px] tracking-[1.4px] uppercase font-medium px-6 py-2.5 rounded-[4px] hover:bg-[#253660] transition-colors">
              Book now
            </button>
          </div>
        </div>
      </header>

      {/* HERO */}
      <div className="relative w-full h-[520px] md:h-[600px] bg-[#c8cdd6] overflow-hidden">
        <img
          alt="The Northern Solstice Resort – aerial view over Norwegian coastline with aurora borealis"
          className="absolute inset-0 w-full h-full object-cover object-center"
          src={imgHero}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[rgba(26,39,68,0.15)] to-[rgba(26,39,68,0.45)]" />
      </div>

      {/* RESORT IDENTITY */}
      <div className="bg-[#f5f5f5] px-8 md:px-12 pt-12 pb-0">
        <div className="max-w-[1280px] mx-auto border-b border-[#e2e2e2] pb-10">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div className="flex flex-col gap-3">
              <p className="text-[#9a9285] text-[10px] tracking-[2.2px] uppercase font-medium">Lofoten Archipelago, Norway</p>
              <h1 className="text-[#1a2744] text-[48px] md:text-[58px] font-bold leading-none tracking-[-0.58px] uppercase" style={{ fontFamily: "'Noto Serif', serif" }}>
                The Northern<br />Solstice<br />Resort
              </h1>
            </div>
            <div className="flex flex-col items-start md:items-end gap-2 pb-1">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  {[1,2,3,4,5].map(i => (
                    <StarIcon key={i} className="overflow-clip relative shrink-0 size-[14px]" variant="1" />
                  ))}
                </div>
                <span className="text-[#888078] text-[11px] tracking-[0.44px]">Exceptional · 94 reviews</span>
              </div>
              <p className="text-[#c8a96e] text-[10px] tracking-[1.6px] uppercase font-medium">Arctic Flagship Property</p>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="bg-[#f5f5f5] px-8 md:px-12 py-12">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-16 lg:gap-20 items-start">
          {/* LEFT */}
          <div className="flex flex-col gap-5">
            {/* Section heading */}
            <div className="flex items-center gap-3">
              <div className="w-[3px] h-[22px] bg-[#c8a96e] shrink-0" />
              <h2 className="text-[#1a2744] text-[28px] md:text-[32px] font-normal leading-none" style={{ fontFamily: "'Noto Serif', serif" }}>A Sanctuary in the Ice</h2>
            </div>

            <p className="text-[#3a3630] text-[13.5px] font-light leading-[1.85]">
              Perched on the jagged cliffs of Norway's northern coast, The Northern Solstice is a masterclass in architectural restraint. Designed to vanish into the landscape, each glass-walled suite offers an unhindered view of the Aurora Borealis and the dark, churning waters of the Norwegian Sea.
            </p>
            <p className="text-[#3a3630] text-[13.5px] font-light leading-[1.85]">
              Our philosophy is rooted in the concept of "Deep Stillness." Here, the modern world recedes, replaced by the rhythmic sound of crashing waves and the crisp, scentless air of the Arctic circle.
            </p>

            {/* Amenities */}
            <div className="flex flex-col gap-6 pt-6">
              <div className="flex items-center justify-between border-b border-[#e2e2e2] pb-4">
                <span className="text-[#9a9285] text-[10px] tracking-[2px] uppercase font-semibold">Curated Amenities</span>
                <span className="text-[#888078] text-[11px] tracking-[0.44px]">16 rooms available</span>
              </div>
              <div className="grid grid-cols-3 gap-0.5">
                {amenities.map(({ variant, category, name }) => (
                  <div key={name} className="bg-white flex flex-col gap-2.5 px-[18px] pt-5 pb-[22px]">
                    <StarIcon className="opacity-70 overflow-clip relative shrink-0 size-[22px]" variant={variant} />
                    <div>
                      <p className="text-[#9a9285] text-[9px] tracking-[1.62px] uppercase font-semibold leading-[14.4px]">{category}</p>
                      <p className="text-[#1a2744] text-[12.5px] font-normal leading-[16.88px] mt-0.5">{name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT — Booking card */}
          <div className="bg-white border border-[#e2e2e2] lg:sticky lg:top-24 p-7 flex flex-col gap-0">
            <p className="text-[#9a9285] text-[9px] tracking-[1.62px] uppercase font-semibold mb-3">Starting From</p>
            <div className="flex items-baseline gap-1.5 pb-5 border-b border-[#e2e2e2]">
              <span className="text-[#1a2744] text-[38px] font-normal leading-none" style={{ fontFamily: "'Noto Serif', serif" }}>€1,850</span>
              <span className="text-[#888078] text-[11px] tracking-[0.44px] font-light">/ night</span>
            </div>

            <div className="mt-4">
              <p className="text-[#9a9285] text-[9.5px] tracking-[1.33px] uppercase font-semibold mb-3">Check In / Check Out</p>
              <div className="bg-[#f5f5f5] border border-[#e2e2e2] flex items-center justify-between px-4 py-3.5">
                <span className="text-[#888078] text-[12.5px] font-light">Select Dates</span>
                <StarIcon className="relative shrink-0 size-[14px]" variant="8" />
              </div>
            </div>

            <div className="mt-4">
              <p className="text-[#9a9285] text-[9.5px] tracking-[1.33px] uppercase font-semibold mb-3">Guests</p>
              <div className="bg-[#f5f5f5] border border-[#e2e2e2] flex items-center justify-between px-4 py-3.5">
                <span className="text-[#3a3630] text-[12.5px] font-light">2 Adults, 0 Children</span>
                <StarIcon className="relative shrink-0 size-[14px]" variant="9" />
              </div>
            </div>

            <button className="mt-6 bg-[#1a2744] text-white text-[10.5px] tracking-[1.68px] uppercase font-semibold py-3.5 w-full hover:bg-[#253660] transition-colors">
              Check Availability
            </button>

            <div className="mt-5 flex flex-col gap-2">
              {["Flexible Cancellation","Airport Transfers"].map(perk => (
                <div key={perk} className="flex items-center gap-2">
                  <StarIcon className="overflow-clip relative shrink-0 size-[13px]" variant="10" />
                  <span className="text-[#888078] text-[11px] tracking-[0.33px]">{perk}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* EXPERIENCE SECTION */}
      <div className="grid grid-cols-1 md:grid-cols-2">
        <div className="bg-[#c8cdd6] h-[400px] md:h-[520px] overflow-hidden relative">
          <img
            alt="Interior living space — floor-to-ceiling glass facing the fjord"
            className="absolute inset-0 w-full h-full object-cover object-center"
            src={imgFjord}
          />
        </div>
        <div className="bg-white flex items-center px-10 md:px-14 py-16 md:py-0 min-h-[400px] md:min-h-[520px]">
          <div className="max-w-[380px]">
            <p className="text-[#c8a96e] text-[9.5px] tracking-[2.09px] uppercase font-semibold mb-4">The Experience</p>
            <h3 className="text-[#1a2744] text-[38px] md:text-[42px] font-normal leading-[1.1] mb-6" style={{ fontFamily: "'Noto Serif', serif" }}>
              Radical<br />Simplicity.
            </h3>
            <p className="text-[#3a3630] text-[13px] font-light leading-[1.85] mb-6">
              Every material used in the construction was locally sourced or recycled, ensuring a carbon-neutral footprint that respects the Arctic ecosystem. Nothing superfluous. Everything intentional.
            </p>
            <a href="#" className="inline-block border-b border-[#1a2744] pb-1 text-[#1a2744] text-[10.5px] tracking-[1.68px] uppercase font-semibold hover:opacity-70 transition-opacity">
              View Sustainable Details
            </a>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="bg-[#1a2744] px-8 md:px-12 py-8">
        <div className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex flex-col gap-1">
            <p className="text-[rgba(255,255,255,0.85)] text-[10.5px] tracking-[2.1px] uppercase font-semibold">Arctic Travels</p>
            <p className="text-[rgba(255,255,255,0.35)] text-[10.5px] tracking-[0.21px] font-light">© 2024 Arctic Travels. Curated Excellence.</p>
          </div>
          <div className="flex items-center gap-8">
            {["Privacy Policy","Terms","Press"].map(link => (
              <a key={link} href="#" className="text-[rgba(255,255,255,0.45)] text-[11px] tracking-[0.66px] font-light hover:text-white transition-colors">{link}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
